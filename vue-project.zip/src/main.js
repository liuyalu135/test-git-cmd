import Vue from 'vue'
import App from './App'
import router from './router'
import axios from 'axios'
// 导入全局自定义样式
import '@/assets/css/global.css'
// 导入字体图标文件样式表
import "@/assets/fonts/iconfont.css"
// 导入element-ui
import ElementUI from 'element-ui'
// 安装element
Vue.use(ElementUI)

// 引入并安装全局组件(树状表格)
import TableTree from 'vue-table-with-tree-grid'
Vue.component("table-tree", TableTree)

axios.defaults.baseURL = "http://127.0.0.1:8888/api/private/v1/"
// 拦截器
axios.interceptors.request.use(function(config) {
  // 在发送请求之前做些什么
  let token = window.sessionStorage.getItem("token");
  config.headers.Authorization = token;
  return config;
});

Vue.prototype.$http = axios


Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  render: h => h(App)
})
