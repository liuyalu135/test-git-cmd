export default {
    data() {
        // 自定义邮箱验证规则
        var checkEmail = function(rule, value, callback) {
            let emailRep = /^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/;
            if(emailRep.test(value)) {
                callback();
            } else {
                callback(new Error('邮箱地址不正确!'))
            }
        };
        // 自定义手机验证规则
        var checkMobile = function(rule, value, callback) {
            let mobileRep = /^1\d{10}$/;
            if(mobileRep.test(value)) {
                callback();
            } else {
                callback(new Error('手机号不正确!'))
            }
        };
        return {
            userList: [],//列表数据
            // 获取列表数据上送参数
            queryInfo: {
                query: "",//搜素关键字
                pagenum: 1,//当前页码
                pagesize: 2//每页条数
            },
            total: 0, //列表数据总条数
            disabled: false,//控制改变用户按钮是否可点击
            addDialogVisible: false,//控制添加用户弹出层显示和隐藏
            editDialogVisible: false,//控制编辑用户弹出层显示和隐藏
            delDialogVisible: false,//控制删除用户弹出层显示和隐藏
            setDialogVisible: false,//控制分配角色弹出层显示和隐藏
            // 添加用户表单数据
            addForm:{
                username:"",//用户名
                password:"",//密码
                email:"",//邮箱
                mobile:"",//手机
            },
            // 添加用户表单验证规则
            addRules:{
                username:[
                    { required: true, message: '请输入用户名', trigger: 'blur' },
                    { min: 3, max: 9, message: '长度在 3 到 9 个字符', trigger: 'blur' }
                ],
                password:[
                    { required: true, message: '请输入密码', trigger: 'blur' },
                    { min: 3, max: 6, message: '长度在 3 到 6 个字符', trigger: 'blur' }
                ],
                email:[
                    { required: true, message: '请输入邮箱', trigger: 'blur' },
                    // 自定义邮箱验证规则
                    {validator: checkEmail, trigger: 'blur' }
                ],
                mobile:[
                    { required: true, message: '请输入手机号', trigger: 'blur' },
                    // 自定义手机号验证规则
                    {validator: checkMobile, trigger: 'blur' }
                ],
            },
            // 编辑用户表单数据
            editForm:{
                id:"",
                username:"",//用户名
                email:"",//邮箱
                mobile:"",//手机
            },
            // 编辑用户表单验证规则
            editRules:{
                email:[
                    { required: true, message: '请输入邮箱', trigger: 'blur' },
                    // 自定义邮箱验证规则
                    {validator: checkEmail, trigger: 'blur' }
                ],
                mobile:[
                    { required: true, message: '请输入手机号', trigger: 'blur' },
                    // 自定义手机号验证规则
                    {validator: checkMobile, trigger: 'blur' }
                ],
            },
            // 分配角色表单数据
            setForm: {
                id: "",//用户ID
                rid:"",//角色ID
                role_name: "", //角色名称
                username: ""//用户名称
            },
            // 角色列表
            roleList:[]
        }
    },
    methods: {
        // 获取列表数据
        async getUserList() {
            let {data: res} = await this.$http.get("/users", {params: this.queryInfo});
            if(res.meta.status != 200) return this.$message.error("请求用户列表数据失败!");
            this.total = res.data.total;
            this.userList = res.data.users;
        },
        // 改变每页条数处理函数
        handleSizeChange(newPageSize) {
            this.queryInfo.pagesize = newPageSize;
            this.getUserList();
        },
        // 改变当前页码处理函数
        handleCurrentChange(newPageNum) {
            this.queryInfo.pagenum = newPageNum;
            this.getUserList();
        },
        // 用户状态改变
        async switchChanged(state,id) {
            this.disabled = true;
            let {data: res} = await this.$http.put(`users/${id}/state/${state}`);
            // 延时三秒后才允许再次改变用户状态
            setTimeout(() => {this.disabled = false}, 3000);
            if(res.meta.status != 200) {
                this.$message.error("修改用户状态失败!");
                this.getUserList();
            } else {
                this.$message.success("修改用户状态成功!");
            }
        },
        // 添加用户弹出层关闭触发
        closeDialogVisible() {
            // 表单重置
            this.$refs.addRef.resetFields();
        },
        // 添加用户
        addUserMessage() {
            this.$refs.addRef.validate(async bool => {
                if(bool) {
                    let {data: res} = await this.$http.post("/users", this.addForm);
                    if(res.meta.status != 201) return 
                    this.$message.error("添加用户失败!");
                    this.$message.success("添加用户成功!");
                    this.addDialogVisible = false;
                    this.getUserList();
                }else {
                    return;
                }
            })
        },
        // 获取用户信息
        async getUserMessage(id) {
            let {data: res} = await this.$http.get(`/users/${id}`);
            if(res.meta.status != 200) return 
            this.$message.error("获取用户信息失败!");
            this.editDialogVisible = true;
            this.$message.success("获取用户信息成功!");
            this.editForm = res.data;
        },
        // 编辑用户
        editUserMessage() {
            this.$refs.editRef.validate(async valid => {
                if(!valid) return;
                let {data: res} = await this.$http.put(`/users/${this.editForm.id}`, this.editForm);
                if(res.meta.status != 200) return 
                this.$message.error("编辑用户信息失败!");
                this.editDialogVisible = false;
                this.$message.success("编辑用户信息成功!");
                this.getUserList();
            })
        },
        // 删除用户
        async remove(id) {
            let confirm = await this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).catch(err => err);
            console.error(confirm)
            if(confirm != "confirm") return this.$message("已取消操作!");
            let {data: res} = await this.$http.delete(`/users/${id}`);
            if(res.meta.status != 200) return 
            this.$message.error("删除用户失败!");
            this.$message.success("删除用户成功!");
            this.getUserList();
        },
        // 获取角色列表
        async getRoleList() {
            let {data:res} = await this.$http.get("/roles");
            if(res.meta.status != 200) return this.$message.error("获取角色列表失败!");
            this.$message.success("获取角色列表成功!");
            this.roleList = res.data;
        },
        // 展示分配用户角色面板
        showSetRole(row) {
            // 显示分配用户角色面板
            this.setDialogVisible = true;
            // 每次打开面板 首先将角色下拉列表选中项置空
            this.setForm.rid = ""; 
            // 将点击的用户列表项数据中需要用到的放到setForm中
            this.setForm.id = row.id;
            this.setForm.role_name = row.role_name;
            this.setForm.username = row.username;
            // 请求下拉角色列表
            this.getRoleList();
        },
        // 分配角色
        async setRole() {
            if(this.setForm.rid == "") return this.$message.warning("新角色不能为空!");
            let {data:res} = await this.$http.put(`users/${this.setForm.id}/role`, {rid: this.setForm.rid});
            console.error(res)
            if(res.meta.status != 200) return this.$message.error("分配新角色失败!");
            this.$message.success("分配新角色成功!"); 
            this.setDialogVisible = false;
            this.getUserList();
        }
    },
    created() {
        this.getUserList();
    }
}