export default {
    data() {
        return {
            rolesList: [],//角色列表数据
            addDialogVisible: false,//添加角色弹出层显隐
            editDialogVisible: false,//编辑角色弹出层显隐
            rightDialogVisible: false,//分配权限弹出层显隐
            addForm: {//添加角色表单数据
                roleName:'',//角色名称
                roleDesc:'',//角色描述
            },
            addRules: {//添加角色表单验证规则
                roleName: [
                    { required: true, message: '请输入角色名称', trigger: 'blur' },
                    { min: 3, max: 9, message: '长度在 3 到 9 个字符', trigger: 'blur' }
                ],
                roleDesc: [
                    { required: true, message: '请输入角色描述', trigger: 'blur' },
                    { min: 3, max: 15, message: '长度在 3 到 15 个字符', trigger: 'blur' }
                ],
            },
            editForm: {//编辑角色表单数据
                id: "",
                roleName:'',//角色名称
                roleDesc:'',//角色描述
            },
            editRules: {//编辑角色表单验证规则
                roleName: [
                    { required: true, message: '请输入角色名称', trigger: 'blur' },
                    { min: 3, max: 9, message: '长度在 3 到 9 个字符', trigger: 'blur' }
                ],
                roleDesc: [
                    { required: true, message: '请输入角色描述', trigger: 'blur' },
                    { min: 3, max: 15, message: '长度在 3 到 15 个字符', trigger: 'blur' }
                ],
            },
            // 所有权限列表数据
            rightTreeList: [],
            // 树结构的配置项
            treeProps: {
                children: 'children',//子节点配置
                label: 'authName'// 页面展示节点文字配置
            },
            // 选中的节点Id
            checkKeys:[],
            // 分配权限用的角色ID
            roleId: ''
        }
    },
    created() {
        this.getRolesList();
    },
    methods: {
        async getRolesList() {
            let {data: res} = await this.$http.get("/roles");
            console.error(res)
            if(res.meta.status != 200) return this.$message.error("获取角色列表失败!");
            this.rolesList = res.data;
        },
        // 添加角色弹出层关闭时表单重置
        dialogFields() {
            this.$refs.addForm.resetFields()
        },
        // 添加角色
        addRole() {
            this.$refs.addForm.validate(async valid => {
                if(!valid) return;
                let {data: res} = await this.$http.post("/roles", this.addForm);
                console.error(res) 
                if(res.meta.status != 201) return this.$message.error("添加角色失败!");
                this.$message.success("添加角色成功!");
                this.addDialogVisible = false;
                this.getRolesList();
            })
        },
        // 编辑角色弹出层关闭时表单重置
        closeEditDialog() {
            this.$refs.editForm.resetFields()
        },
        // 点击编辑按钮  显示编辑弹出层
        async editShow(id) {
            this.editDialogVisible = true;
            let {data: res} = await this.$http.get("/roles/"+id);
            console.error(res);
            this.editForm.id = res.data.roleId;
            this.editForm.roleName = res.data.roleName;
            this.editForm.roleDesc = res.data.roleDesc;
        },
        // 编辑角色信息提交
        editRole() {
            this.$refs.editForm.validate(async valid => {
                if(!valid) return;
                let {data: res} = await this.$http.put("/roles/"+this.editForm.id, this.editForm);
                if(res.meta.status != 200) return this.$message.error("编辑角色失败!");
                this.$message.success("编辑角色成功!");
                this.editDialogVisible = false;
                this.getRolesList();
            })
        },
        // 删除角色
        async delRole(id) {
            let confirm = await this.$confirm('此操作将永久删除该角色, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).catch(err => err);
            if(confirm != "confirm") return this.$message("已取消操作!");
            let {data: res} = await this.$http.delete("/roles/"+id);
            if(res.meta.status != 200) return this.$message.error("删除角色失败!");
            this.$message.success("删除角色成功!");
            this.getRolesList();
        },
        // 删除权限
        async removeRight(row, id) {
            let confirm = await this.$confirm('此操作将永久删除该权限, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).catch(err => err);
            if(confirm != "confirm") return this.$message("已取消操作!");
            let {data: res} = await this.$http.delete(`/roles/${row.id}/rights/${id}`);
            console.error(row.id)
            console.error(id)
            console.error(res)
            if(res.meta.status != 200) return this.$message.error("删除权限失败!");
            this.$message.success("删除权限成功!");
            row.children = res.data;
        },
        // 通过递归的方法获取角色下的所有三级权限Id
        getRightId(node, rightIdArr) {
            if(!node.children) {
                rightIdArr.push(node.id);
            }else {
                node.children.forEach(item => {
                    this.getRightId(item, rightIdArr);
                })
            }
        },
        // 展示权限分配面板
        async showRight(row) {
            this.roleId = row.id;
            // 调用递归方法获取角色下的所有三级权限Id
            let keys = [];
            this.getRightId(row, keys);
            this.checkKeys = keys;
            // 获取所有权限列表数据
            let {data: res} = await this.$http.get("/rights/tree");
            if(res.meta.status != 200) return this.$message.error("获取所有权限列表数据失败!");
            this.rightTreeList = res.data;
            this.rightDialogVisible = true;
        },
        // 分配权限
        async setRight() {
            let halfCheckedKeys = this.$refs.rightTree.getHalfCheckedKeys();
            let getCheckedKeys = this.$refs.rightTree.getCheckedKeys();
            let rids = getCheckedKeys.concat(halfCheckedKeys).join(",");
            console.error(this.checkKeys)
            console.error(rids)
            let {data: res} = await this.$http.post(`/roles/${this.roleId}/rights`, {rids: rids});
            console.error(res)
            if(res.meta.status != 200) return this.$message.error("角色授权失败!");
            this.$message.success("角色授权成功!");
            this.rightDialogVisible = false;
            this.getRolesList();
        }
    }
}