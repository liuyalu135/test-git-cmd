<template>
<div>
    <!-- 面包屑导航 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>权限管理</el-breadcrumb-item>
        <el-breadcrumb-item>角色列表</el-breadcrumb-item>
    </el-breadcrumb>
    
    <!-- 卡片内容区域 -->
    <el-card>
        <!-- 添加角色按钮 -->
        <el-button type="primary" @click="addDialogVisible = true">添加角色</el-button>
        <!-- 角色列表区域 -->
        <el-table :data="rolesList" border style="width: 99.9%">
            <el-table-column type="expand">
                <template slot-scope="scope">
                    <el-row v-for="(itemOne, index) in scope.row.children" :key="itemOne.id"  :class="['borderBot', index == 0 ? 'borderTop': '']">
                        <el-col :span="4">
                            <el-tag closable @close="removeRight(scope.row, itemOne.id)">{{itemOne.authName}}</el-tag>
                        </el-col>
                        <el-col :span="20" class="margin0">
                            <el-row v-for="itemTwo in itemOne.children" :key="itemTwo.id">
                                <el-col :span="6">
                                    <i class="el-icon-caret-right"></i>
                                    <el-tag @close="removeRight(scope.row, itemTwo.id)" closable type="success">{{itemTwo.authName}}</el-tag>
                                </el-col>
                                <el-col :span="18">
                                    <i class="el-icon-caret-right"></i>
                                    <el-tag closable type="warning" @close="removeRight(scope.row, itemThe.id)" v-for="itemThe in itemTwo.children" :key="itemThe.id">{{itemThe.authName}}</el-tag>
                                </el-col>
                            </el-row>
                        </el-col>
                    </el-row>
                </template>    
            </el-table-column>
            <el-table-column label="#" type="index"></el-table-column>
            <el-table-column prop="roleName" label="角色名称"></el-table-column>
            <el-table-column prop="roleDesc" label="描述"></el-table-column>
            <el-table-column label="操作" width="320px">
                <template slot-scope="scope">
                    <el-button type="primary"  icon="el-icon-edit" size="mini" @click="editShow(scope.row.id)">编辑</el-button>
                    <el-button type="danger"  icon="el-icon-delete" size="mini"
                    @click="delRole(scope.row.id)">删除</el-button>
                    <el-button type="warning"  icon="el-icon-setting" size="mini" @click="showRight(scope.row)">分配权限</el-button>
                </template>
            </el-table-column>
        </el-table>
    </el-card>

    <!-- 添加角色弹出层 --> 
    <el-dialog
    title="添加角色"
    @close="dialogFields"
    :visible.sync="addDialogVisible"
    width="50%">
        <el-form :model="addForm" :rules="addRules" ref="addForm" label-width="100px">
            <el-form-item label="角色名称" prop="roleName">
                <el-input v-model="addForm.roleName"></el-input>
            </el-form-item>
            <el-form-item label="角色描述" prop="roleDesc">
                <el-input v-model="addForm.roleDesc"></el-input>
            </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
            <el-button @click="addDialogVisible = false">取 消</el-button>
            <el-button type="primary" @click="addRole">确 定</el-button>
        </span>
    </el-dialog>

    <!-- 编辑角色弹出层 --> 
    <el-dialog
    title="添加角色"
    @close="closeEditDialog"
    :visible.sync="editDialogVisible"
    width="50%">
        <el-form :model="editForm" :rules="editRules" ref="editForm" label-width="100px">
            <el-form-item label="角色名称" prop="roleName">
                <el-input v-model="editForm.roleName"></el-input>
            </el-form-item>
            <el-form-item label="角色描述" prop="roleDesc">
                <el-input v-model="editForm.roleDesc"></el-input>
            </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
            <el-button @click="editDialogVisible = false">取 消</el-button>
            <el-button type="primary" @click="editRole">确 定</el-button>
        </span>
    </el-dialog>

    <!-- 分配权限弹出层 --> 
    <el-dialog
    title="分配权限"
    :visible.sync="rightDialogVisible"
    width="50%">
        <el-tree
        ref="rightTree"
        node-key="id"
        default-expand-all
        :default-checked-keys="checkKeys"
        :data="rightTreeList"
        :props="treeProps"
        show-checkbox>
        </el-tree>

        <span slot="footer" class="dialog-footer">
            <el-button @click="rightDialogVisible = false">取 消</el-button>
            <el-button type="primary" @click="setRight">确 定</el-button>
        </span>
    </el-dialog>
</div>
</template>
<script>
    import mix from "./Roles-mixins.js"
    export default {
        mixins: [mix]
    }
</script>
<style lang="less" scoped>
    .el-breadcrumb {
        margin-bottom: 20px;
    }
    .el-button {
        margin-bottom: 15px;
    }
    .borderBot {
        border-bottom: 1px solid #ddd;
    }
    .borderTop {
        border-top: 1px solid #ddd;
    }
    .el-col {
        margin: 10px 0;
    }
    .el-icon-caret-right {
        margin-right: 15px;
    }
    .margin0 {
        margin:0;
    }
</style>

