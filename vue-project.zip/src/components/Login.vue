<template>
    <div class="login">
        <!-- 登录Logo -->
        <div class="logo">
            <img src="../assets/logo.png">
        </div>
        <!-- Form表单 -->
        <el-form :model="loginForm" :rules="loginFormRules" ref="loginFormRefs" label-width="0px" 
        class="loginForm_style">
            <el-form-item prop="username">
                <el-input v-model="loginForm.username">
                    <i slot="prefix" class="iconfont icon-user"></i>
                </el-input>
            </el-form-item>
            <el-form-item prop="password">
                <el-input v-model="loginForm.password" type="password">
                     <i slot="prefix" class="iconfont icon-3702mima"></i>
                </el-input>
            </el-form-item>
            <el-form-item class="btns">
                <el-button type="primary" size="small" @click="login">登录</el-button>
                <el-button type="info" size="small" @click="resetForm">重置</el-button>
            </el-form-item>
        </el-form>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                // 登录用户名和密码数据
                loginForm: {
                    username:"admin",
                    password:"123456"
                },
                // 登录表单验证规则
                loginFormRules: {
                    username: [
                        { required: true, message: '请输入登录用户名称', trigger: 'blur' },
                        { min: 3, max: 8, message: '长度在 3 到 8 个字符', trigger: 'blur' }
                    ],
                    password: [
                        { required: true, message: '请输入登录用户密码', trigger: 'blur' },
                        { min: 6, max: 15, message: '长度在 6 到 15 个字符', trigger: 'blur' }
                    ],
                }
            }
        },
        methods: {
            resetForm() {
                this.$refs.loginFormRefs.resetFields()
            },
            login() {
                // 表单验证
                this.$refs.loginFormRefs.validate(async (valid) => {
                    // 验证失败
                    if(!valid) return;
                    // 验证成功
                    console.error(9999)
                    let {data: res} = await this.$http.post("/login", this.loginForm);
                    console.error(res)
                    // 登录失败
                    if(res.meta.status != 200) return this.$message.error("登录失败!");
                    // 登录成功
                    this.$message.success("登录成功!");
                    window.sessionStorage.setItem("token", res.data.token);
                    this.$router.push("/home");

                })
            }
        }
    }
</script>
<style scoped lang="less">
    .login {
        background: #fff;
        width: 450px;
        height:304px;
        border-radius: 10px;
        padding: 0 20px;
        box-sizing: border-box;
        position: absolute;
        top:20%;
        left:50%;
        transform: translateX(-50%);

        .logo {
            width:100px;
            height:100px;
            padding: 8px;
            border-radius: 50%;
            border: 1px solid #eee;
            box-shadow: 0 0 3px #eee;
            background: #fff;
            position: absolute;
            left: 50%;
            transform: translateX(-50%) translateY(-60px);

            img {
                width: 100%;
                height:100%;
                border-radius: 50%;
                background: #eee;
            }
            
        }

        .loginForm_style {
            margin-top: 110px;

            .btns {
                display: flex;
                justify-content: flex-end;
            }
        }
    }
</style>

