<template>
  <el-container>
    <el-header>
      <div class="logo_title">
        <img src="../assets/heima_logo.png">
        <div>电商后台管理系统</div>
      </div>
      <el-button type="info" @click="logout">退出</el-button>
    </el-header>
    <!-- 下方内容部分 -->
    <el-container>
      <!-- 侧边栏 -->
      <el-aside :width="flag ? '65px' : '200px'" ref="aside">
        <!-- 折叠条 -->
        <div class="toggleBar" @click="flag=!flag">|||</div>
        <!-- 侧边栏菜单 -->
        <el-menu
          router
          unique-opened
          :collapse="flag"
          :collapse-transition="false"
          default-active="2"
          class="el-menu-vertical-demo"
          background-color="#333744"
          text-color="#fff"
          active-text-color="#409EFF">
          <el-submenu :index="item.id + ''" v-for="item in menus" :key="item.id">
            <template slot="title">
              <i :class="['iconfont', iconObj[item.authName]]"></i>
              <span>{{item.authName}}</span>
            </template>
            <el-menu-item :index="subitem.id + ''" :route="subitem.path"  v-for="subitem in item.children" :key="subitem.id">
              <i class="el-icon-menu"></i>
              <span>{{subitem.authName}}</span>
            </el-menu-item>
          </el-submenu>
        </el-menu>
      </el-aside>
      <!-- 右边内容主体 -->
      <el-main>
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
  export default {
    data() {
      return {
        flag: false,
        menus: [],
        iconObj: {
          "用户管理": 'icon-users',
          "权限管理":"icon-tijikongjian",
          "商品管理":"icon-shangpin",
          "订单管理":"icon-danju",
          "数据统计":"icon-baobiao",
        }
      }
    },
    methods: {
      logout() {
        window.sessionStorage.removeItem("token");
        this.$router.push("/login")
      },
      async getmenus() {
        let {data: res} = await this.$http.get("menus");
        if(res.meta.status != 200) return this.$message.error("获取左侧菜单列表失败!");
        return this.menus = res.data;
      }
    },
    created() {
      this.getmenus();
    }
  }
</script>

<style lang="less" scoped>
.el-container {
  height: 100%;
}
.el-header {
  background-color: #373d41;
  display: flex;
  justify-content: space-between;
  align-items: center;
  user-select: none;

  .logo_title {
    display: flex;
    align-items: center;
    color: white;
    
    div {
      margin-left: 20px;
    }
  }
}
.el-aside {
  background-color: #333744;
  user-select: none;
  .iconfont {
    margin-right: 8px;
  }
  .toggleBar {
    line-height: 24px;
    font-size: 12px;
    letter-spacing: 0.2em;
    text-align: center;
    color: #fff;
    background-color: #4a5064;
    cursor: pointer;
  }
  .el-menu {
    border: none;
  }
}
.el-main {
  background-color: #EAEDF1;
}
</style>

