export default {
    data() {
        return {
            // 选中的商品分类Id
            selectedCate:[],
            // 三级商品分类列表
            cataList: [],
            // 级联商品分类选择框配置项
            cateProps:{
                value:'cat_id',
                label:'cat_name',
                children:'children'
            },
            // 页签选中项
            activeName: "many",
            // 参数或属性列表数据
            tableList: [],
            // 控制添加参数或属性弹出框显示
            addDialogVisible: false,
            // 添加参数或属性表单数据
            addForm: {
                attr_name: ''
            },
            // 添加参数或属性表单验证规则
            addRule: {
                attr_name: [
                    { required: true, message: '请输入参数或属性名称', trigger: 'blur' }
                ]
            },
            //  控制修改参数或属性弹出框显示
            editDialogVisible: false,
            // 修改参数或属性表单数据
            editForm: {
                attr_id: '',
                attr_name: ''
            },
            // 修改参数或属性表单验证规则
            editRule: {
                attr_name: [
                    { required: true, message: '请输入参数或属性名称', trigger: 'blur' }
                ]
            },
            // 控制动态编辑标签显示
            inputVisible: false,
            // 动态编辑标签输入框值
            inputValue: '',
        }
    }, 
    methods: {
        // 获取级联列表数据
        async getCateList() {
            let {data:res} = await this.$http.get('/categories',{params:{type:3}});
            console.error(res)
            if(res.meta.status != 200) return this.$message.error("获取级联分类列表失败!");
            this.$message.success("获取级联分类列表成功!");
            this.cataList = res.data;
        },
        // 获取表格参数或属性列表
        async getTableList() {
            let {data:res} = await this.$http.get(`categories/${this.selectedCate[2]}/attributes`,{params:{sel:this.activeName}});
            console.error(res)
            if(res.meta.status != 200) return this.$message.error("获取参数或属性失败!");
            res.data.forEach(item => {
                item.attr_vals = item.attr_vals ? item.attr_vals.split(" ") : [];
            });
            this.$message.success("获取参数或属性成功!");
            this.tableList = res.data;
        },
        // 改变级联列表选中项
        cateChange() {
            console.error(this.selectedCate)
            if(this.selectedCate.length < 3){
                this.selectedCate = []
                this.tableList = []
            }else {
                this.getTableList()
            }
        },
        // 页签切换
        tabChange() {
            console.error(this.activeName)
            this.getTableList()
        },
        // 关闭添加对话框 重置表单
        closeAddDialog() {
            this.$refs.addRef.resetFields();
        },
        // 添加属性或参数
        addAttr() {
            this.$refs.addRef.validate(async valid => {
                if(!valid) return;
                let {data:res} = await this.$http.post(`categories/${this.selectedCate[2]}/attributes`,{attr_name:this.addForm.attr_name, attr_sel:this.activeName});
                console.error(res)
                if(res.meta.status != 201) return this.$message.error("添加参数或属性失败!");
                this.$message.success("添加参数或属性成功!");
                this.addDialogVisible = false;
                this.getTableList()
            })
        },
        // 显示修改对话框
        showEditDialog(row) {
            console.error(row)
            this.editDialogVisible = true;
            this.editForm.attr_id = row.attr_id;
            this.editForm.attr_name = row.attr_name;
        },
        // 关闭修改对话框 重置表单
        closeEditDialog() {
            this.$refs.editRef.resetFields();
        },
        // 修改属性或参数
        eidtAttr() {
            this.$refs.editRef.validate(async valid => {
                if(!valid) return;
                let {data:res} = await this.$http.put(`categories/${this.selectedCate[2]}/attributes/${this.editForm.attr_id}`,{attr_name:this.editForm.attr_name, attr_sel:this.activeName});
                console.error(res)
                if(res.meta.status != 200) return this.$message.error("修改参数或属性失败!");
                this.$message.success("修改参数或属性成功!");
                this.editDialogVisible = false;
                this.getTableList()
            })
        },
        // 删除属性
        async removeAttr(row) {
            let confirm = await this.$confirm('此操作将永久删除该属性, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).catch(err => err)
            console.error(confirm)
            if(confirm !== "confirm") return this.$message({
                type: 'info',
                message: '已取消删除'
            });
            let {data: res} = await this.$http.delete(`categories/${this.selectedCate[2]}/attributes/${row.attr_id}`);
            console.error(res)
            if(res.meta.status !== 200) 
            return this.$message.error("删除属性提交失败!");
            this.$message.success("删除属性提交成功!");
            this.getTableList()
        },
        // 添加标签
        async handleInputConfirm(row) {
            this.inputVisible = false
            if(!this.inputValue.trim()) {
                return this.inputValue = "";
            }
            row.attr_vals.push(this.inputValue);
            this.inputValue = '';
            let {data:res} = await this.$http.put(`categories/${this.selectedCate[2]}/attributes/${row.attr_id}`,{attr_name:row.attr_name, attr_sel:this.activeName,attr_vals: row.attr_vals.join(" ")});
            console.error(res)
            if(res.meta.status != 200) return this.$message.error("添加标签失败!");
            this.$message.success("添加标签成功!");
        },
        showInput() {
            this.inputVisible = true;
            this.$nextTick(_ => {
                console.error(this.$refs.saveTagInput)
                this.$refs.saveTagInput.$refs.input.focus();
            });
        },
        async tagClose(row,i) {
            row.attr_vals.splice(i,1);
            let {data:res} = await this.$http.put(`categories/${this.selectedCate[2]}/attributes/${row.attr_id}`,{attr_name:row.attr_name, attr_sel:this.activeName,attr_vals: row.attr_vals.join(" ")});
            console.error(res)
            if(res.meta.status != 200) return this.$message.error("添加标签失败!");
            this.$message.success("添加标签成功!");
        }
    },
    created() {
        console.error(99)
        this.getCateList();
    }
}