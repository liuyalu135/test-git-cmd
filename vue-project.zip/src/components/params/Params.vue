<template>
    <div>
        <!-- 导航栏 -->
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>商品管理</el-breadcrumb-item>
            <el-breadcrumb-item>参数列表</el-breadcrumb-item>
        </el-breadcrumb>
        <el-card>
            <!-- 提示语 -->
            <el-alert
                title="注意: 只能为第三级分类设置相关参数!"
                type="warning"
                show-icon>
            </el-alert>
            <!-- 级联选择框 -->
            <el-row>
                <el-col>
                    选择商品分类:
                    <el-cascader
                    expand-trigger="hover"
                    v-model="selectedCate"
                    :options="cataList"
                    :props="cateProps"
                    @change="cateChange">
                    </el-cascader>
                </el-col>
            </el-row>
            <!-- 页签 -->
            <el-tabs v-model="activeName" @tab-click="tabChange">
                <el-tab-pane label="动态参数" name="many">
                    <el-button type="primary" size="mini" :disabled="selectedCate.length === 3 ? false: true" @click="addDialogVisible = true">添加参数</el-button>
                </el-tab-pane>
                <el-tab-pane label="静态属性" name="only">
                    <el-button type="primary" size="mini" :disabled="selectedCate.length === 3 ? false: true" @click="addDialogVisible = true">添加属性</el-button>
                </el-tab-pane>
            </el-tabs>
            <!-- 参数或属性列表 -->
            <el-table border stripe :data="tableList" style="width: 100%">
                <el-table-column type="expand" width="80">
                    <template slot-scope="scope">
                        <el-tag v-for="(item,i) in scope.row.attr_vals" :key="i" closable @close="tagClose(scope.row,i)">
                            {{item}}
                        </el-tag>
                        <!-- 动态编辑标签 -->
                        <el-input
                        class="input-new-tag"
                        v-if="inputVisible"
                        v-model="inputValue"
                        ref="saveTagInput"
                        size="small"
                        @keyup.enter.native="handleInputConfirm(scope.row)"
                        @blur="handleInputConfirm(scope.row)"
                        >
                        </el-input>
                        <el-button v-else class="button-new-tag" size="small" @click="showInput">+ New Tag</el-button>
                    </template>
                </el-table-column>
                <el-table-column label="#" type="index" width="80">
                </el-table-column>
                <el-table-column prop="attr_name" width="280"
                    :label="activeName == 'many' ? '参数名称' : '属性名称'">
                </el-table-column>
                <el-table-column label="操作">
                    <template slot-scope="scope">
                        <el-button type="primary" icon="el-icon-edit" size="mini" @click="showEditDialog(scope.row)">修改</el-button>
                        <el-button type="danger" icon="el-icon-delete" size="mini"
                        @click="removeAttr(scope.row)">删除</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </el-card>
        <!-- 添加参数或属性弹出框 -->
        <el-dialog :title="activeName=='many' ? '添加动态参数' : '添加静态属性'" :visible.sync="addDialogVisible" width="50%" @close="closeAddDialog">
            <!-- 添加参数或属性表单 -->
            <el-form :model="addForm" :rules="addRule" ref="addRef" label-width="100px" class="demo-ruleForm">
                <el-form-item :label="activeName=='many' ? '动态参数' : '静态属性'" prop="attr_name">
                    <el-input v-model="addForm.attr_name"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="addDialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="addAttr">确 定</el-button>
            </span>
        </el-dialog>
        <!-- 编辑参数或属性弹出框 -->
        <el-dialog :title="activeName=='many' ? '修改动态参数' : '修改静态属性'" :visible.sync="editDialogVisible" width="50%" @close="closeEditDialog">
            <!-- 添加参数或属性表单 -->
            <el-form :model="editForm" :rules="editRule" ref="editRef" label-width="100px" class="demo-ruleForm">
                <el-form-item :label="activeName=='many' ? '动态参数' : '静态属性'" prop="attr_name">
                    <el-input v-model="editForm.attr_name"></el-input>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="editDialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="eidtAttr">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
import mix from "./Params-mixins.js"
export default {
    mixins: [mix]
}
</script>

<style lang="less" scoped>
.el-alert {
    margin-bottom: 15px;
}
.el-card {
    margin-top: 15px;
}
.el-cascader {
    width: 260px;
}
.input-new-tag {
    width: 150px;
}
</style>

