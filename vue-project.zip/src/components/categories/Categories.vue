<template>
    <div>
        <!-- 导航栏 -->
        <el-breadcrumb separator-class="el-icon-arrow-right">
            <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
            <el-breadcrumb-item>商品管理</el-breadcrumb-item>
            <el-breadcrumb-item>商品分类</el-breadcrumb-item>
        </el-breadcrumb>
        <el-card class="marginTop">
             <!-- 添加角色按钮 -->
            <el-button type="primary" @click="showAddDialog">添加分类</el-button>
            <!-- 树状表格 -->
            <table-tree 
                border
                show-row-hover
                stripe
                :show-index="true"
                index-text="#"
                :data="categoryList"
                :columns="columns"
                :selection-type="false"
                :expand-type="false"
                >
                <template slot="isOk" slot-scope="scope">
                    <i v-if="scope.row.cat_deleted" class="el-icon-circle-check success"></i>
                    <i v-else class="el-icon-circle-close danger"></i>
                </template>
                <template slot="handle" slot-scope="scope">
                    <el-button icon="el-icon-edit" type="primary" size="mini" @click="showEditDialog(scope.row)">编辑</el-button>
                    <el-button icon="el-icon-delete" type="danger" size="mini" @click="deleteCate(scope.row)">删除</el-button>
                </template>
            </table-tree> 
            <!-- 分页 -->
            <el-pagination
            @current-change="handleCurrentChange"
            :current-page="getListParams.pagenum"
            :page-size="getListParams.pagesize"
            layout="total, prev, pager, next, jumper"
            :total="total">
            </el-pagination>
        </el-card>
        <!-- 添加分类弹出框 -->
        <el-dialog
            @close="closeDialog"
            title="添加分类"
            :visible.sync="addDialogVisible"
            width="50%">
            <el-form :model="addForm" :rules="addRule" ref="addRef" label-width="100px" class="demo-ruleForm">
                <el-form-item label="分类名称" prop="cat_name">
                    <el-input v-model="addForm.cat_name"></el-input>
                </el-form-item>
                <el-form-item label="父级分类">
                    <el-cascader
                        expand-trigger="hover"
                        v-model="selectedPcate"
                        :options="pcateList"
                        :props="pcateProps"
                        :change-on-select="true"
                        @change="pcateChange"
                        :clearable="true">
                    </el-cascader>
                </el-form-item>
            </el-form>
            <span slot="footer" class="dialog-footer">
                <el-button @click="addDialogVisible = false">取 消</el-button>
                <el-button type="primary" @click="addCate">确 定</el-button>
            </span>
        </el-dialog>
        <!-- 编辑分类对话框 -->
        <el-dialog
        title="编辑分类信息"
        :visible.sync="editDialogVisible"
        width="50%" @close="closeEditDialog">
        <el-form :model="editForm" :rules="editRule" ref="editRef" label-width="100px" class="demo-ruleForm">
            <el-form-item label="分类名称" prop="cat_name">
                <el-input v-model="editForm.cat_name"></el-input>
            </el-form-item>
        </el-form>
        <span slot="footer" class="dialog-footer">
            <el-button @click="editDialogVisible = false">取 消</el-button>
            <el-button type="primary" @click="editCate">确 定</el-button>
        </span>
        </el-dialog>
    </div>
</template>

<script>
import mix from "./Categories-mixins.js"
export default {
    mixins:[mix]
}
</script>

<style lang="less" scoped>
    .marginTop {
        margin-top: 15px;
    }
    .success {
        color: green;
    }
    .danger {
        color: red;
    }
    .el-cascader {
        width: 100%;
    }
</style>

