export default {
    data() {
        return {
            getListParams: {
                type:3,
                pagenum:1,
                pagesize:5
            },
            total: 0,
            categoryList:[],
            columns:[
                {
                    label: "分类名称",
                    prop: "cat_name"
                },
                {
                    label: "是否有效",
                    type: 'template',
                    template: 'isOk'
                },
                {
                    label: "排序",
                    prop: "cat_level"
                },
                {
                    label: "操作",
                    type: 'template',
                    template: 'handle',
                    width:200
                },
            ],
            // 控制添加分类弹出框显示
            addDialogVisible: false,
            // 添加分类表单数据
            addForm: {
                cat_pid: 0,//父分类Id
                cat_name: '', //分类名称
                cat_level: 0// 分类层级
            },
            // 添加分类表单验证规则
            addRule: {
                cat_name: [
                    { required: true, message: '请输入分类名称', trigger: 'blur' }
                ]
            },
            // 父级分类列表数据
            pcateList:[],
            // 选中项Id数据
            selectedPcate:[],
            // 父级分类级联选择配置
            pcateProps:{
                value:'cat_id',
                label:'cat_name',
                children:'children'
            },
            // 控制编辑分类对话框显示
            editDialogVisible: false,
            // 编辑分类表单数据
            editForm: {
                id:'',
                cat_name: ''
            },
            // 编辑分类表单验证规则
            editRule: {
                cat_name: [
                    { required: true, message: '请输入分类名称', trigger: 'blur' }
                ]
            }
        }
    },
    methods: {
        // 获取商品分类列表数据
        async getCategoryList() {
            let {data: res} = await this.$http.get("/categories",{params:this.getListParams});
            console.error(res)
            if(res.meta.status != 200) return this.$message.error("获取分类列表失败!");
            this.$message.success("获取分类列表成功!");
            this.total = res.data.total;
            this.categoryList = res.data.result;
        },
        // 改变当前页面  刷新列表
        handleCurrentChange(newPageNum) {
            this.getListParams.pagenum = newPageNum;
            this.getCategoryList();
        },
        // 点击添加分类按钮  展示添加分类弹出框
        async showAddDialog() {
            // 获取级联列表数据
            let {data:res} = await this.$http.get('/categories',{params:{type:2}});
            if(res.meta.status != 200) return this.$message.error("获取级联分类列表失败!");
            this.$message.success("获取级联分类列表成功!");
            this.pcateList = res.data;
            // 显示添加分类弹出框
            this.addDialogVisible = true
        },
        // 级联选择框选中项改变
        pcateChange() {
            // 设置分类层级
            this.addForm.cat_level = this.selectedPcate.length;
            // 设置父分类Id
            if(this.selectedPcate == 0) {
                this.addForm.cat_pid = 0;
            }else {
                this.addForm.cat_pid = this.selectedPcate[this.selectedPcate.length-1];
            }
            console.error(this.addForm)
        },
        // 添加分类
        addCate() {
            this.$refs.addRef.validate(async valid => {
                if(!valid) return;
                console.error(this.addForm)
                let {data:res} = await this.$http.post("/categories", this.addForm);
                console.error(res)
                if(res.meta.status != 201) return this.$message.error("添加分类失败!");
                this.$message.success("添加分类成功!");
                this.addDialogVisible = false;
                this.getCategoryList()
            })
        },
        // 关闭添加分类弹出框 重置添加分类表单数据addForm
        closeDialog() {
            this.addForm.cat_level =  this.addForm.cat_pid = 0;
            this.addForm.cat_name = '';
            this.selectedPcate = [];
        },
        // 点击编辑按钮 展示编辑分类对话框
        showEditDialog(row) {
            this.editForm.id = row.cat_id;
            this.editForm.cat_name = row.cat_name;
            this.editDialogVisible = true;
        },
        // 编辑分类对话框关闭 重置表单
        closeEditDialog() {
            this.editForm.id = '';
            this.editForm.cat_name = '';
        },
        // 编辑提交分类
        editCate() {
            this.$refs.editRef.validate(async valid => {
                console.error(this.editForm.id)
                if(!valid) return;
                let {data: res} = await this.$http.put("/categories/"+this.editForm.id, {cat_name: this.editForm.cat_name});
                console.error(res)
                if(res.meta.status !== 200) 
                return this.$message.error("编辑分类提交失败!");
                this.$message.success("编辑分类提交成功!");
                this.editDialogVisible = false;
                this.getCategoryList()
            })
        },
        // 删除分类
        async deleteCate(row) {
            let confirm = await this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).catch(err => err)
            console.error(confirm)
            if(confirm !== "confirm") return this.$message({
                type: 'info',
                message: '已取消删除'
            });
            let {data: res} = await this.$http.delete("/categories/"+row.cat_id);
            console.error(res)
            if(res.meta.status !== 200) 
            return this.$message.error("删除分类提交失败!");
            this.$message.success("删除分类提交成功!");
            this.getCategoryList()
        }
    },
    created() {
        this.getCategoryList()
    }
}