export default {
    data() {
        return {
            rightsList: []
        }
    },
    created() {
        this.getRightsList()
    },
    methods: {
        async getRightsList() {
            let {data: res} = await this.$http.get("/rights/list");
            if(res.meta.status != 200) return this.$message.error("获取权限列表失败!");
            this.rightsList = res.data;
        }
    },
}