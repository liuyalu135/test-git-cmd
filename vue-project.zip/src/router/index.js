import Vue from 'vue'
import Router from 'vue-router'
import Login from '@/components/Login'
import Home from '@/components/Home'
import Welcome from '@/components/Welcome'
import Users from '@/components/users/Users'
import Rights from '@/components/powser/Rights'
import Roles from '@/components/roles/Roles'
import Categories from '@/components/categories/Categories'
import Params from '@/components/params/Params'

Vue.use(Router)

let router = new Router({
  routes: [
    {
      path: '/',
      redirect: "/login"
    },
    {
      path: '/login',
      component: Login
    },
    {
      path: '/home',
      component: Home,
      redirect: "/welcome",
      children: [
        {path: "/welcome", component: Welcome},
        {path: "/users", component: Users},
        {path: "/rights", component: Rights},
        {path: "/roles", component: Roles},
        {path: "/categories", component: Categories},
        {path: "/params", component: Params},
      ]
    },
  ]
})

// 路由导航守卫
router.beforeEach((to, from, next)=>{
  // 去登录页面
  if(to.path == "/login") return next();
  // 获取登录令牌
  let token = window.sessionStorage.getItem("token");
  if(!token) return next("/login");
  next();
})


export default router;